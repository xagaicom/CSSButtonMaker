# CSS Button Maker - Deployment Guide

## Platform-Specific Deployment Instructions

### 1. Railway Deployment (Recommended)

Railway is the easiest deployment option with automatic builds and PostgreSQL support.

**Steps:**
1. Create a Railway account at https://railway.app
2. Connect your GitHub repository
3. Create a new project and link your repository
4. Add a PostgreSQL database service
5. Set environment variables:
   - `DATABASE_URL` (automatically set by Railway)
   - `SESSION_SECRET` (generate a random string)
6. Deploy automatically with git push

**Configuration:**
- Use `deployment-configs/railway.json` for advanced settings
- Railway will automatically detect Node.js and run build commands

### 2. Vercel Deployment

Vercel is great for serverless deployment with automatic scaling.

**Steps:**
1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in the project directory
3. Follow the setup prompts
4. Set environment variables in Vercel dashboard
5. Deploy with `vercel --prod`

**Configuration:**
- Copy `deployment-configs/vercel.json` to root directory
- Set up PostgreSQL database (recommend Railway or Neon)
- Configure environment variables in Vercel dashboard

### 3. Digital Ocean App Platform

Digital Ocean provides a managed platform with database integration.

**Steps:**
1. Create a Digital Ocean account
2. Go to App Platform and create a new app
3. Connect your GitHub repository
4. Add a PostgreSQL database
5. Use `deployment-configs/digital-ocean.yaml` for app spec
6. Set environment variables in DO dashboard

**Configuration:**
- Automatic builds and deployments
- Managed PostgreSQL database
- Built-in health checks

### 4. Heroku Deployment

Heroku is a classic PaaS with easy PostgreSQL integration.

**Steps:**
1. Install Heroku CLI
2. Create a Heroku app: `heroku create css-button-maker`
3. Add PostgreSQL addon: `heroku addons:create heroku-postgresql:essential-0`
4. Set environment variables: `heroku config:set SESSION_SECRET=your-secret`
5. Deploy: `git push heroku main`

**Configuration:**
- Use `deployment-configs/heroku.json` for app configuration
- Procfile automatically created
- Database migrations run automatically

### 5. VPS/Self-Hosted Deployment

For maximum control, deploy on your own server.

**Requirements:**
- Ubuntu/Debian VPS
- Node.js 18+
- PostgreSQL 15+
- Nginx (recommended)
- PM2 (process manager)

**Steps:**
1. Set up your VPS with Node.js and PostgreSQL
2. Clone the repository: `git clone your-repo.git`
3. Install dependencies: `npm install`
4. Build the application: `npm run build`
5. Set up database: `npm run db:push`
6. Configure environment variables in `.env`
7. Set up PM2: `pm2 start deployment-configs/pm2.config.js`
8. Configure Nginx: use `deployment-configs/nginx.conf`
9. Set up SSL with Let's Encrypt

**Process Management:**
- Use PM2 for process management
- Set up automatic restarts
- Configure logging and monitoring

### 6. Docker Deployment

For containerized deployment across any platform.

**Steps:**
1. Build the Docker image: `docker build -t css-button-maker .`
2. Run with Docker Compose: `docker-compose up -d`
3. Or deploy to any container platform (AWS ECS, Google Cloud Run, etc.)

**Configuration:**
- Use provided `Dockerfile` and `docker-compose.yml`
- Set environment variables in compose file
- Includes PostgreSQL database container

## Environment Variables

### Required Variables

```env
DATABASE_URL=postgresql://user:password@host:port/database
SESSION_SECRET=your-super-secret-session-key-minimum-32-characters
NODE_ENV=production
PORT=5000
```

### Optional Variables

```env
# Database connection details (if not using DATABASE_URL)
PGHOST=localhost
PGPORT=5432
PGUSER=username
PGPASSWORD=password
PGDATABASE=css_button_maker

# Replit Auth (if using Replit deployment)
REPLIT_DOMAINS=your-domain.com
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
```

## Database Setup

### PostgreSQL Installation

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**Create Database:**
```sql
sudo -u postgres psql
CREATE DATABASE css_button_maker;
CREATE USER appuser WITH PASSWORD 'your-password';
GRANT ALL PRIVILEGES ON DATABASE css_button_maker TO appuser;
\q
```

### Database Migration

After setting up the database, run migrations:
```bash
npm run db:push
```

## SSL Certificate Setup

For production deployments, always use HTTPS:

**Let's Encrypt (Free):**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

**Manual SSL:**
- Upload certificate files to server
- Configure Nginx with SSL settings
- Update nginx.conf with certificate paths

## Performance Optimization

### Production Optimizations

1. **Enable Gzip Compression** (in Nginx)
2. **Set up CDN** for static assets
3. **Configure Database Connection Pooling**
4. **Enable HTTP/2** in Nginx
5. **Set up Redis** for session storage (optional)

### Monitoring

**Recommended Tools:**
- **PM2 Monitor**: Built-in process monitoring
- **New Relic**: Application performance monitoring
- **Sentry**: Error tracking and monitoring
- **Uptime Robot**: Uptime monitoring

## Security Checklist

- [ ] Change default admin credentials
- [ ] Set strong SESSION_SECRET
- [ ] Configure HTTPS/SSL
- [ ] Set up firewall rules
- [ ] Enable database backups
- [ ] Configure security headers
- [ ] Set up log monitoring
- [ ] Regular security updates

## Troubleshooting

### Common Issues

1. **Build Failures**: Check Node.js version (18+)
2. **Database Connection**: Verify DATABASE_URL format
3. **Port Issues**: Ensure PORT environment variable is set
4. **Static Files**: Check build output in `dist/public`
5. **Session Issues**: Verify SESSION_SECRET is set

### Logs

Check application logs:
```bash
# PM2 logs
pm2 logs css-button-maker

# System logs
sudo journalctl -u css-button-maker -f

# Docker logs
docker logs css-button-maker
```

## Support

For deployment issues:
1. Check the platform-specific documentation
2. Review the error logs
3. Verify environment variables
4. Test database connectivity
5. Check build output

Common deployment platforms have their own support channels and documentation for troubleshooting specific issues.