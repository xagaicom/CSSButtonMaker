# CSS Button Maker - Complete Deployment Package

## Overview

This is a complete deployment package for the CSS Button Maker web application - a professional React-based gradient button designer with live preview, code generation, and comprehensive admin system.

## Features

- **Advanced Button Designer**: 50+ preset button styles across 15 categories
- **Live Preview**: Real-time button preview with hover/click effects
- **Code Generation**: CSS/HTML code export with copy/download functionality
- **Admin System**: Complete admin panel for managing custom buttons and ads
- **Google AdSense Integration**: 5 strategic ad placement locations
- **User Authentication**: Secure login system with session management
- **Database Storage**: PostgreSQL with saved designs and user management
- **Modern UI**: Built with React 18, TypeScript, Tailwind CSS, and shadcn/ui

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express.js, PostgreSQL, Drizzle ORM
- **Authentication**: Passport.js with session management
- **Database**: PostgreSQL with Drizzle ORM
- **Build Tools**: Vite, esbuild, PostCSS

## Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- npm or yarn

### Installation

1. **Clone and install dependencies**:
   ```bash
   cd css-button-maker
   npm install
   ```

2. **Set up environment variables**:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your database URL and session secret.

3. **Set up database**:
   ```bash
   npm run db:push
   ```

4. **Development**:
   ```bash
   npm run dev
   ```

5. **Production**:
   ```bash
   npm run build
   npm start
   ```

## Deployment Options

### Option 1: Railway (Recommended)
- Upload the entire package to Railway
- Set environment variables in Railway dashboard
- Auto-deploy with git push

### Option 2: Vercel
- Upload to Vercel
- Configure build settings (see vercel.json)
- Set environment variables in Vercel dashboard

### Option 3: Digital Ocean App Platform
- Upload to Digital Ocean
- Configure app spec (see .do/app.yaml)
- Set environment variables in DO dashboard

### Option 4: Heroku
- Upload to Heroku
- Set buildpacks for Node.js
- Configure environment variables

### Option 5: VPS/Self-Hosted
- Upload to your server
- Install Node.js and PostgreSQL
- Configure reverse proxy (nginx/apache)
- Set up SSL certificate

## Environment Variables

Required environment variables:

```env
DATABASE_URL=postgresql://user:password@host:port/database
SESSION_SECRET=your-super-secret-session-key
NODE_ENV=production
PORT=3000
```

Optional (for advanced features):
```env
REPLIT_DOMAINS=your-domain.com
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
```

## Database Schema

The application automatically creates the following tables:
- `users` - User authentication and profiles
- `sessions` - Session storage
- `button_designs` - Saved button designs
- `widget_layouts` - Widget configurations
- `custom_buttons` - Admin-created custom buttons
- `ad_spaces` - Google AdSense ad placements
- `app_settings` - Application configuration

## Admin Panel

Access the admin panel at `/admin-panel` with these default credentials:
- Username: `admin`
- Password: `admin123`

**Important**: Change these credentials immediately after deployment!

## Performance Optimizations

- Vite build optimization for production
- Code splitting and lazy loading
- Optimized asset delivery
- PostgreSQL connection pooling
- Session storage optimization

## Security Features

- CSRF protection
- Session management
- Input validation
- SQL injection prevention
- XSS protection
- Secure headers

## Monetization

The app includes Google AdSense integration with 5 strategic ad placements:
1. Header Banner (728x90)
2. Left Sidebar (300x250)
3. Right Sidebar (320x50)
4. CSS Output (728x90)
5. Modal Popup (300x250)

Configure ads through the admin panel at `/admin-panel`.

## Support

For deployment issues or questions, refer to the platform-specific documentation in the `/deployment-configs` folder.

## License

MIT License - See LICENSE file for details.